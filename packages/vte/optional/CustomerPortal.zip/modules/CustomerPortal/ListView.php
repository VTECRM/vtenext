<?php
/*************************************
 * SPDX-FileCopyrightText: 2009-2020 Vtenext S.r.l. <info@vtenext.com> 
 * SPDX-License-Identifier: AGPL-3.0-only  
 ************************************/
 
global $app_strings, $mod_strings, $current_language, $currentModule, $theme, $current_user;
require_once('include/ListView/ListView.php');
require_once('modules/CustomView/CustomView.php');
require_once('include/DatabaseUtil.php');
require_once('modules/CustomerPortal/PortalUtils.php');
require('user_privileges/user_privileges_'.$current_user->id.'.php');

if(!is_admin($current_user)) {
    $smarty = new VteSmarty();
    $smarty->assign('APP', $app_strings);
    $smarty->assign("THEME", $theme);
    $smarty->display("modules/CustomerPortal/ListViewPortal.tpl");
	exit;
}

if($_REQUEST['sub_mode'] != '' && isset($_REQUEST['sub_mode'])){
	$sub_mode =$_REQUEST['sub_mode']; 
}
if($sub_mode == 'movemodules'){
	$tabid = $_REQUEST['tabid'];
	$move = $_REQUEST['move'];
	if($tabid != ''){
		cp_changeTabOrder($tabid,$move);
	}
}elseif($sub_mode == 'enable_disable') {
	$tabid = $_REQUEST['tabid'];
	$status =$_REQUEST['status'];
	if($status != '' && $tabid != ''){
		cp_changeModuleVisibility($tabid,$status);
	} 
}
$category = getParentTab();
$smarty = new VteSmarty();
$portalmodules = cp_getPortalModuleinfo();

$smarty->assign('PORTALMODULES',$portalmodules); 
$smarty->assign("THEME", $theme);
$smarty->assign('MOD', $mod_strings);
$smarty->assign('APP', $app_strings);
$smarty->assign('BUTTONS', $list_buttons);
$smarty->assign('CHECK', $tool_buttons);
$smarty->assign('MODULE', $currentModule);
$smarty->assign('CATEGORY', $category);
$smarty->assign('IMAGE_PATH', "themes/$theme/images/");
$smarty->assign('MODE',$mode);
$smarty->assign("MODSETTINGS", return_module_language($current_language,'Settings')); //crmv@30683
if($_REQUEST['ajax'] != true) {
	$smarty->display(vtlib_getModuleTemplate($currentModule,'BasicSetttings.tpl'));
}
else {
	$smarty->display(vtlib_getModuleTemplate($currentModule,'BasicSetttingsContents.tpl'));
}