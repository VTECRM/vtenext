/*************************************
 * SPDX-FileCopyrightText: 2009-2020 Vtenext S.r.l. <info@vtenext.com> 
  * SPDX-License-Identifier: AGPL-3.0-only  
 ************************************/

/* crmv@192033 */

function move_module(tabid,move) {
	jQuery.ajax({
		url: 'index.php',
		method: 'POST',
		data: 'module=CustomerPortal&action=CustomerPortalAjax&file=ListView&sub_mode=movemodules&parenttab=Settings&tabid='+tabid+'&move='+move+'&ajax=true',
		success: function(result) {
			jQuery("#portallist").html(result);
		}
	});	
}

function toggleModule(tabid, action) {
	var data = 'module=CustomerPortal&action=CustomerPortalAjax&file=ListView&tabid='+tabid+'&sub_mode=enable_disable&status='+action; 
	jQuery.ajax({
		url: 'index.php',
		method: 'POST',
		data: data,
		success: function(result) {
			// Reload the page to apply the effect of module setting
			window.location.href = "index.php?module=CustomerPortal&action=index&parenttab=Settings";
		}
	});
}