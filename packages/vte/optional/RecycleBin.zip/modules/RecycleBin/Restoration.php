<?php
/*************************************
 * SPDX-FileCopyrightText: 2009-2020 Vtenext S.r.l. <info@vtenext.com> 
 * SPDX-License-Identifier: AGPL-3.0-only  
 ************************************/

if(isset($_REQUEST['idlist']) && $_REQUEST['idlist'] != '')
{
	$idlists = explode(',',$_REQUEST[idlist]);
}elseif(isset($_REQUEST['entityid']) && $_REQUEST['entityid'] != '')
{
	$idlists = Array($_REQUEST['entityid']);
}

$selected_module = vtlib_purify($_REQUEST['selectmodule']);
require_once('data/CRMEntity.php');
$focus = CRMEntity::getInstance($selected_module);

for($i=0;$i<count($idlists);$i++) {
	if(!empty($idlists[$i])) {
		$focus->restore($mod_name, $idlists[$i]);
	}
}

$parenttab = getParentTab();

header("Location: index.php?module=RecycleBin&action=RecycleBinAjax&file=index&parenttab=$parenttab&mode=ajax&selected_module=$selected_module");
?>