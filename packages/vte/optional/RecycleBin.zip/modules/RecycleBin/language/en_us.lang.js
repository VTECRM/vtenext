/*************************************
 * SPDX-FileCopyrightText: 2009-2020 Vtenext S.r.l. <info@vtenext.com> 
  * SPDX-License-Identifier: AGPL-3.0-only  
 ************************************/

var mod_alert_arr = {       
	SELECT_ATLEAST_ONE_ENTITY:'Please select at least one entity',
	MSG_RESTORE_CONFIRMATION:'Are you sure you want to restore the selected',
	RECORD : 'record ',
	RECORDS : 'records ',
	THE : 'the ',
	MSG_EMPTY_RB_CONFIRMATION: 'Are you sure, you want to Permanently remove all the deleted records from your database?',
};