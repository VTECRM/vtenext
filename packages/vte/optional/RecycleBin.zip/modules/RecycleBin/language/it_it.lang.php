<?php
/*************************************
 * SPDX-FileCopyrightText: 2009-2020 Vtenext S.r.l. <info@vtenext.com> 
 * SPDX-License-Identifier: AGPL-3.0-only  
 ************************************/

$mod_strings = Array(
'RecycleBin' => 'Cestino',
'MSG_EMPTY_RB_CONFIRMATION'=>'Sicuro di voler rimuovere Permanentemente tutti i record eliminati dal database?',
'LBL_SELECT_MODULE'=>'Seleziona Modulo',
'LBL_EMPTY_MODULE'=>'Nessun record trovato da Ripristinare nel modulo',
'LBL_MASS_RESTORE'=>'Ripristina',
'LBL_EMPTY_RECYCLEBIN'=>'Svuota Cestino',
'LNK_RESTORE'=>'ripristina',
'LBL_NO_PERMITTED_MODULES'=>'Nessun modulo consentito disponibile',
);

?>