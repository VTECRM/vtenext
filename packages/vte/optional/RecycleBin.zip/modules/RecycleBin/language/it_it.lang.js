/*************************************
 * SPDX-FileCopyrightText: 2009-2020 Vtenext S.r.l. <info@vtenext.com> 
  * SPDX-License-Identifier: AGPL-3.0-only  
 ************************************/

var mod_alert_arr = {       
	SELECT_ATLEAST_ONE_ENTITY : 'Prego selezionare almeno una voce',
	MSG_RESTORE_CONFIRMATION : 'Sicuro di voler ripristinare ',
	RECORD : 'entit\u00E0 ',
	RECORDS : 'entit\u00E0 ',
	THE : 'l\' ',
	MSG_EMPTY_RB_CONFIRMATION: 'Sicuro di voler rimuovere Permanentemente tutti i record eliminati dal database?',
};