<?php
/*************************************
 * SPDX-FileCopyrightText: 2009-2020 Vtenext S.r.l. <info@vtenext.com> 
 * SPDX-License-Identifier: AGPL-3.0-only  
 ************************************/

/* crmv@95157 */

require_once('modules/Documents/storage/StorageBackendUtils.php');
 
global $adb,$table_prefix;

//crmv@71058
$res = $adb->query('SELECT setype FROM '.$table_prefix.'_crmentity WHERE deleted=1 GROUP BY setype');
while($row = $adb->fetchByAssoc($res)){
	$focus = CRMEntity::getInstance($row['setype']);
	foreach($focus->tab_name_index as $table=>$key){
		if($table == $table_prefix.'_crmentity') continue;
		
		$query="DELETE $table FROM $table INNER JOIN {$table_prefix}_crmentity ON {$table_prefix}_crmentity.crmid = $table.$key WHERE deleted=1";
		$adb->query($query);
	}
}
//crmv@71058e

$adb->query('DELETE FROM '.$table_prefix.'_crmentity WHERE deleted = 1');
//TODO Related records for the module records deleted from vte_crmentity has to be deleted. 
//It needs lookup in the related tables and needs to be removed if doesn't have a reference record in vte_crmentity
 
$adb->query('DELETE FROM '.$table_prefix.'_relatedlists_rb');

// remove orphaned attachments
$SBU = StorageBackendUtils::getInstance();
$SBU->deleteOrphanAttachments();

// crmv@144125
// remove old entityname entries
$ENU = EntityNameUtils::getInstance();
$ENU->removeDeletedEntries();
// crmv@144125e

$parenttab = getParentTab();

header("Location: index.php?module=RecycleBin&action=RecycleBinAjax&file=index&parenttab=$parenttab&mode=ajax");